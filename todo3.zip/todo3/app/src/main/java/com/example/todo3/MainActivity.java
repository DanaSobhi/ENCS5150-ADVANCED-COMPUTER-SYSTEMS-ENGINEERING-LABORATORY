package com.example.todo3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button buttonSave;
    Button buttonClear;
    Button buttonNew;
    SharedPrefManager sharedPrefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Button buttonSave = findViewById(R.id.saveQ);
        Button buttonClear= findViewById(R.id.clearQ);
        Button buttonNew = findViewById(R.id.newQ);

        TextView viewQuote =  findViewById(R.id.textView);
        sharedPrefManager =SharedPrefManager.getInstance(this);


        buttonClear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                sharedPrefManager.removeQuotes();
                viewQuote.setText(sharedPrefManager.readString("Quote","No Quote"));
            }
        });

        buttonNew.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                viewQuote.setText(selectRandom());
            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sharedPrefManager.writeString("Quote",viewQuote.getText().toString());
                Toast.makeText(MainActivity.this, "Values written to shared Preferences",
                        Toast.LENGTH_SHORT).show();
            }
        });
        viewQuote.setText(sharedPrefManager.readString("Quote","No Quote"));
    }

    public String selectRandom() {
        ArrayList<String> qoutes = new ArrayList<>();
        qoutes.add("Quote1");
        qoutes.add("Quote2");
        qoutes.add("Quote3");
        qoutes.add("Quote4");
        qoutes.add("Quote5");

        Random random = new Random();
        return qoutes.get(random.nextInt(4));
    }
}