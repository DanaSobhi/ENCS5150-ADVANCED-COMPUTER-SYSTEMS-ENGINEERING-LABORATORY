package com.example.todo1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Hangman extends AppCompatActivity {


    int incorrectL = 0;
    String guessedL = "";
    TextView theWord, warningsD, gameOverM, head, body, rightArm, leftArm, rightLeg, leftLeg;;
    EditText inputL;
    Button enterLB, restartGB;
    String firstName, lastName, suId;
    String birzeitW = "birzeit";
    StringBuilder currentL = new StringBuilder("-------");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hangman);

        for (Registered_data studentS : Registered_data.registeredData) {
            firstName = studentS.getsNameFirst();
            lastName = studentS.getsNameLast();
            suId = String.valueOf(studentS.getsId());
        }

        theWord = findViewById(R.id.wordDisplay);
        warningsD = findViewById(R.id.warningGame);
        gameOverM = findViewById(R.id.gameOver);

        TextView playerInfoDisplay = findViewById(R.id.playerInfoDisplay);


        inputL = findViewById(R.id.guessedLetter);
        enterLB = findViewById(R.id.enterLetter);
        restartGB = findViewById(R.id.restartGame);


        head = findViewById(R.id.head);
        body = findViewById(R.id.body);
        rightArm = findViewById(R.id.rightArm);
        leftArm = findViewById(R.id.leftArm);
        rightLeg = findViewById(R.id.righLeg);
        leftLeg = findViewById(R.id.leftLeg);



        playerInfoDisplay.setText("Welcome : " + firstName + " " + lastName + " " +suId);

        theWord.setText(currentL.toString());


        hideFigure();
        gameOverM.setVisibility(View.INVISIBLE);
         restartGB.setVisibility(View.INVISIBLE);


            enterLB.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String letter = inputL.getText().toString().toLowerCase();
                        inputL.setText("");

                        if (letter.length() != 1) {
                            warningsD.setText("Please enter a one letter!");
                        } else if (guessedL.contains(letter)) {
                            warningsD.setText("You already entered this letter!");
                        } else {
                            guessedL += letter;
                            checkGuess(letter);
                        }
                    }
         });


        restartGB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    reset();
                }
        });
    }


    private void checkGuess(String letter) {
        boolean cGuess = false;

        for (int i = 0; i < birzeitW.length(); i++) {
            if (birzeitW.charAt(i) == letter.charAt(0)) {
                currentL.setCharAt(i, letter.charAt(0));
                cGuess = true;
            }
        }

        if (cGuess) {
            warningsD.setText("Correct guess!");
            theWord.setText(currentL.toString());

                if (currentL.toString().equals(birzeitW)) {

                    warningsD.setText("Congratulations, " + firstName + "! You won the game, The word was Birziet");

                    enterLB.setEnabled(false);
                    enterLB.setVisibility(View.GONE);
                     restartGB.setVisibility(View.VISIBLE);

                    inputL.setEnabled(false);
                }
        }
        else {
                incorrectL++;
                warningsD.setText("Wrong guess!");

                checkState();

                if (incorrectL >= 6) {
                    warningsD.setText("Sorry " + firstName + "! You lost the game. The word was '" + birzeitW + "'.");

                    enterLB.setEnabled(false);

                    enterLB.setVisibility(View.GONE);
                    restartGB.setVisibility(View.VISIBLE);
                     gameOverM.setVisibility(View.VISIBLE);

                    inputL.setEnabled(false);

                }
        }
    }

//checking incorrect guesses to update the figure
    private void checkState() {
            switch (incorrectL) {
                case 1:
                    head.setVisibility(View.VISIBLE);
                    break;

                case 2:
                    body.setVisibility(View.VISIBLE);
                    break;

                case 3:
                    rightArm.setVisibility(View.VISIBLE);
                    break;

                case 4:
                    leftArm.setVisibility(View.VISIBLE);
                    break;

                case 5:
                    rightLeg.setVisibility(View.VISIBLE);
                    break;

                case 6:
                    leftLeg.setVisibility(View.VISIBLE);
                    break;
            }
    }


    private void hideFigure() {
        head.setVisibility(View.INVISIBLE);
        body.setVisibility(View.INVISIBLE);
        rightArm.setVisibility(View.INVISIBLE);
        leftArm.setVisibility(View.INVISIBLE);
        rightLeg.setVisibility(View.INVISIBLE);
        leftLeg.setVisibility(View.INVISIBLE);
    }


    private void reset() {
        incorrectL = 0;
        guessedL = "";
        warningsD.setText("");

        currentL = new StringBuilder("-------");
         theWord.setText(currentL.toString());

        gameOverM.setVisibility(View.INVISIBLE);

        inputL.setEnabled(true);

        hideFigure();

        enterLB.setEnabled(true);
        enterLB.setVisibility(View.VISIBLE);
        restartGB.setVisibility(View.GONE);


    }
}
