package com.example.todo1;

/* i wasn't sure if i should add a login database but i added it for accuracy*/

import java.util.ArrayList;

public class Registered_data {
    public static ArrayList<Registered_data> registeredData = new ArrayList<>();

    private long sId; // student ID

    private String sNameFirst;

    private String sNameLast;


    public Registered_data() {

    }
    public Registered_data(Long sId, String sNameFirst, String sNameLast)
    {
        this.sId=sId;
        this.sNameFirst=sNameFirst;
        this.sNameLast=sNameLast;
    }

    public long getsId() {
        return sId;
    }

    public void setsId(long sId) {
        this.sId = sId;
    }

    public String getsNameFirst() {
        return sNameFirst;
    }

    public void setsNameFirst(String sNameFirst) {
        this.sNameFirst = sNameFirst;
    }

    public String getsNameLast() {
        return sNameLast;
    }

    public void setsNameLast(String sNameLast) {
        this.sNameLast = sNameLast;
    }


}
