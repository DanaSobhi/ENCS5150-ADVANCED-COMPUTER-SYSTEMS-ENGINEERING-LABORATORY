package com.example.todo1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

// Required information are First name, Last name, and Student ID
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        EditText suID = findViewById(R.id.studentId); // student ID
        EditText suFirstName = findViewById(R.id.firstName); // student first name
        EditText suLastName = findViewById(R.id.lastName); // student last name

        TextView warningsText = findViewById(R.id.warning);

        Button registerS = findViewById(R.id.registerButton); // button to register data.


        registerS.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                Registered_data newStudent = new Registered_data();
                if(suID.getText().toString().isEmpty())
                    warningsText.setText("Missing ID");
                else
                    newStudent.setsId(Long.parseLong(suID.getText().toString()));

                if(suFirstName.getText().toString().isEmpty())
                    warningsText.setText("Missing Fist name");
                else
                    newStudent.setsNameFirst(suFirstName.getText().toString());

                if(suLastName.getText().toString().isEmpty())
                    warningsText.setText("Missing Last name");
                else
                    newStudent.setsNameLast(suLastName.getText().toString());

                if (!suID.getText().toString().isEmpty() && !suFirstName.getText().toString().isEmpty() && !suLastName.getText().toString().isEmpty()) {
                    Registered_data.registeredData.add(newStudent);


                    Intent intent = new Intent(MainActivity.this, Hangman.class);
                    MainActivity.this.startActivity(intent);
                    finish();

                }





            }
        });




    }
}