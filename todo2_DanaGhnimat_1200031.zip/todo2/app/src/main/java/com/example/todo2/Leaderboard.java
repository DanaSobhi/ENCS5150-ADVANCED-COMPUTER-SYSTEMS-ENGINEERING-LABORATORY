package com.example.todo2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;




public class Leaderboard extends AppCompatActivity {

        private TextView infomations;
        private EditText playerNickname;
        private Button leaderBoardB,
                totalPlayersB,
                retrieveB,
                avgScoreB,
                searchPlayerB,
                highestScoreB,
                startNewGameB;
        private LinearLayout searchPlayerlayout;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_leaderboard);

            DataBaseHelper dataBaseHelper =new DataBaseHelper(Leaderboard.this,"todo2",null,1);

            leaderBoardB= (Button)findViewById(R.id.leaderBoardButton);
            totalPlayersB= (Button)findViewById(R.id.totalPlayersButton);
            retrieveB=(Button)findViewById(R.id.retrieveButton);
            avgScoreB=(Button)findViewById(R.id.avgScoreButton);

            highestScoreB=(Button)findViewById(R.id.highestScoreButton);

            startNewGameB = (Button)findViewById(R.id.startNewGameButton);

            infomations = findViewById(R.id.detailsOfQueries);
            playerNickname = findViewById(R.id.playerNickname);
            searchPlayerB=(Button)findViewById(R.id.searchPlayerButton);
            searchPlayerlayout = (LinearLayout)findViewById(R.id.searchPlayerDisplay);

            searchPlayerlayout.setVisibility(View.GONE);


            startNewGameB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(Leaderboard.this,MainActivity.class);
                    Leaderboard.this.startActivity(intent);
                    finish();
                }
            });


            retrieveB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    searchPlayerlayout.setVisibility(View.VISIBLE);

                }
            });


            searchPlayerB.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    String sName = playerNickname.getText().toString();
                    if (!sName.isEmpty()) {
                        Cursor cursor = dataBaseHelper.getPlayerScore(sName);
                        if (cursor != null) {
                            try {
                                if (cursor.moveToFirst()) {
                                    infomations.setTextSize(25);
                                    infomations.setText(
                                            "\nName = " + cursor.getString(0) +
                                                    "\nScore= " + cursor.getString(1) +
                                                    "\nDate= " + cursor.getString(2) +
                                                    "\n\n"
                                    );
                                } else {
                                    infomations.setText("Player not found.");
                                }
                            } finally {
                                cursor.close();
                            }
                        } else {
                            infomations.setText("Error retrieving player score.");
                        }
                    }


                }
            });


            leaderBoardB.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Cursor cursor = dataBaseHelper.getTopScores();
                    StringBuilder leaderboardText = new StringBuilder();
                    infomations.setTextSize(25);
                    if (cursor != null) {
                        while (cursor.moveToNext()) {
                            leaderboardText.append(
                                    "\nName = " + cursor.getString(0) +
                                            "\tScore= " + cursor.getString(1) + "\n");
                        }
                    }
                    infomations.setText(leaderboardText.toString());


                }
            });

            totalPlayersB.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    infomations.setTextSize(25);
                    int total = dataBaseHelper.getNumberofPlayers();
                    infomations.setText("Total players: "+total+"");

                }
            });

            avgScoreB.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    float avg =dataBaseHelper.getAverageScoreAll();
                    infomations.setText("Average score: "+avg+"");

                }
            });



            highestScoreB.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Cursor cursor = dataBaseHelper.getHighestScore();
                    infomations.setTextSize(25);

                    while (cursor.moveToNext()) {
                        infomations.setText(
                                "\nNickname = " + cursor.getString(1) +
                                "\nScore= " + cursor.getString(4) +
                                "\n At = " + cursor.getString(5)

                        );
                    }
                }
            });





        }
    }
