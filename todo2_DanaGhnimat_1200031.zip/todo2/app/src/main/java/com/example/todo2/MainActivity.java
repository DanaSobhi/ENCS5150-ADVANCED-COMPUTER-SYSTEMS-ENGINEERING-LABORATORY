package com.example.todo2;

import android.app.DatePickerDialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Calendar;
import java.time.LocalDate;
import java.time.Period;

public class MainActivity extends AppCompatActivity {


    private TextView errors;
    private EditText username
                    ,email;
    private EditText birthday;
    private Button register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        errors = (TextView) findViewById(R.id.errorHandler);
        username =(EditText) findViewById(R.id.usernameEditText);
        email =(EditText)findViewById(R.id.emailEditText);
        birthday =(EditText) findViewById(R.id.birthdayEditText);
        register=(Button) findViewById(R.id.startButton);


        birthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                birthday.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth); //same as SQL  YYYY-MM-DD
                            }
                        },year, month, day);

                datePickerDialog.show();
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterPlayer();

                String check =  errors.getText().toString();

                if(check.equals("Added, welcome to the game.")) {
                    Intent intent = new Intent(MainActivity.this, Quiz.class);
                    MainActivity.this.startActivity(intent);
                    finish();
                }


            }
        });


    }
    private void RegisterPlayer() {

        Player newPlayer = new Player();

        String user = username.getText().toString();
        String emil = email.getText().toString();
        String brthday = birthday.getText().toString();
        boolean hasErrors = false;


        errors.setText("");


        if (user.isEmpty()) {

            errors.append("Missing Username\n");
            hasErrors = true;
        }
        else {
            newPlayer.setdPlayerUser(user);
        }



        if (emil.isEmpty()) {

            errors.append("Missing Email address\n");
            hasErrors = true;

        }
        else if(emil.matches("(?i).*@.*\\.com")) {
                newPlayer.setdPlayerEmail(emil);
        }
        else{
            errors.append("Email is incorrect\n");
            hasErrors = true;

        }


        if (brthday.isEmpty()) {
            errors.append("Missing Birthday\n");
            hasErrors = true;
        }
        else {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            try {
                LocalDate date = LocalDate.parse(brthday, formatter);
                if (isOldEnough(date, 10)) {
                    newPlayer.setdPlayerBirthday(brthday);
                }
                else {
                    errors.append("You must be at least 10 years ikd\n");
                    hasErrors = true;
                }
            }

            catch (DateTimeParseException e) {
                errors.append("Invalid date format. Use YYYY-MM-DD\n");
                hasErrors = true;
            }
        }

        if (!hasErrors) {

            try {
                newPlayer.setdPlayerScore(0);
                newPlayer.setdPlayerScoreTime(LocalTime.now().toString());

                DataBaseHelper dataBaseHelper =new DataBaseHelper(MainActivity.this,"todo2",null,1);
                errors.setText(dataBaseHelper.addPlayer(newPlayer));
            }

            catch (Exception e) {
                errors.append("Error while setting player data: " + e.getMessage() + "\n");
            }

        }
    }


    public static boolean isOldEnough(LocalDate birthDate, int requiredAge) {
            LocalDate currentDate = LocalDate.now();
            int age = Period.between(birthDate, currentDate).getYears();
            return age >= requiredAge;}

}
