package com.example.todo2;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;

import java.util.Objects;


public class DataBaseHelper extends android.database.sqlite.SQLiteOpenHelper {

    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE PLAYERS(ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT UNIQUE NOT NULL, EMAIL TEXT, BIRTHDATE TEXT, SCORE INTEGER, SCORETIME TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
    }

    public String addPlayer(Player player) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("USERNAME", player.getdPlayerUser());
        contentValues.put("EMAIL", player.getdPlayerEmail());
        contentValues.put("BIRTHDATE", player.getdPlayerBirthday());
        contentValues.put("SCORE", player.getdPlayerScore());
        contentValues.put("SCORETIME", player.getdPlayerScoreTime());


        try {
            long result = sqLiteDatabase.insertOrThrow("PLAYERS", null, contentValues);

            if (result == -1) {
                return "There's an error, try again.";

            } else {

                return "Added, welcome to the game.";

            }


        } catch (SQLiteConstraintException e) {
            if (Objects.requireNonNull(e.getMessage()).contains("UNIQUE constraint failed")) {
                return "Name already exists; try another name.";

            }
        }
        return "";
    }
    


    public Cursor getlastPlayer() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM PLAYERS ORDER BY ID DESC LIMIT 1", null);

    }

    public void updatePlayerScore(int idPlayer, int sc, String scoreTimee) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("SCORE", sc);
        contentValues.put("SCORETIME", scoreTimee);
        sqLiteDatabase.update("PLAYERS", contentValues, "ID = ?", new String[]{String.valueOf(idPlayer)});

    }

    public int getNumberofPlayers() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT COUNT(*) FROM PLAYERS", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();
        return count;
    }

    public Cursor getTopScores() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT USERNAME,SCORE FROM PLAYERS ORDER BY SCORE DESC LIMIT 5", null);
    }

    public float getAverageScoreAll(){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT AVG(SCORE) AS AverageScores FROM PLAYERS", null);
        float avg = 0;

        if (cursor.moveToFirst()) {
            avg = cursor.getFloat(0);
        }
        cursor.close();
        return avg;
    }

    public Cursor getHighestScore(){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM PLAYERS ORDER BY SCORE DESC LIMIT 1", null);
    }

    public Cursor getPlayerScore(String nickname){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String query = "SELECT USERNAME,SCORE,SCORETIME FROM PLAYERS WHERE USERNAME= ?";
        return sqLiteDatabase.rawQuery(query, new String[]{nickname});
    }


}
