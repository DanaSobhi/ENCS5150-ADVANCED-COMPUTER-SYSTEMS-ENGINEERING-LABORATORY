package com.example.todo2;

import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.graphics.Color;
import android.icu.text.DecimalFormat;
import android.icu.text.NumberFormat;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;


public class Quiz extends AppCompatActivity {


    private TextView questoinN,questionDetail,timerView,errors;
    private Spinner options;
    private Button submitB,nextQB;
    private List<Question> questionList;
    private List<Question> selectedQuestions;
    private String correctAnswer;
    private int currentQuestionNum;
    int attempt;
    private CountDownTimer questionTimer;
    int currentScore;
    private String currentDateTime;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz);

        questoinN= (TextView)findViewById(R.id.questoinNumber);
        questionDetail=(TextView)findViewById(R.id.questionDetails);
        timerView=(TextView)findViewById(R.id.timerViewer);

        options =(Spinner) findViewById(R.id.answerOption);
        submitB =(Button) findViewById(R.id.submitButton);

        nextQB =(Button)findViewById(R.id.nextQuestion);
        errors =(TextView)findViewById(R.id.errorsDetector);

        currentQuestionNum=0;
        attempt=0;
        currentScore=0;

        nextQB.setText("Start");

        submitB.setVisibility(View.GONE);


        nextQB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                
                if(attempt <= 5) {
                    
                    if (questionTimer != null) {
                        questionTimer.cancel();
                    }
                    questionList = loadQuestionsFromCSV();
                    selectedQuestions = selectRandomQuestions(questionList, 5);
                    displayQuestion();
                    nextQB.setVisibility(View.GONE);

                    submitB.setVisibility(View.VISIBLE);
                    List<String> randomOptions = getRandomOptions();
                    ArrayAdapter<String> objAnswerOptions = new
                            ArrayAdapter<>(Quiz.this, android.R.layout.simple_spinner_item, randomOptions);
                    options.setAdapter(objAnswerOptions);
                    options.setEnabled(true);


                    questionTimer = new CountDownTimer(10000, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {
                            NumberFormat f = new DecimalFormat("00");
                            long sec = (millisUntilFinished / 1000) % 60;
                            timerView.setText(f.format(sec));
                        }

                        
                        @Override
                        public void onFinish() {
                            if (attempt == 5){
                                timerView.setText("00 Time out! End of the quiz");
                                nextQB.setText("Go to leaderBoard");
                                nextQB.setVisibility(View.VISIBLE);
                                errors.setVisibility(View.VISIBLE);
                                options.setEnabled(false);
                                Date currentTime = new Date();
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                currentDateTime = dateFormat.format(currentTime);
                                String feedback = "your score is: '"+currentScore+"'\n taken in: '"+currentDateTime+" ' ";
                                errors.setTextColor(Color.BLUE);
                                errors.setText(feedback);
                                errors.setTextSize(25);
                                submitB.setVisibility(View.GONE);

                                attempt++;
                                addPlayerPoints();
                                nextQB.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        Intent intent=new Intent(Quiz.this,Leaderboard.class);
                                        Quiz.this.startActivity(intent);
                                        finish();

                                    }
                                });
                            }
                            else {
                                errors.setText("Time out! you missed a point");
                                errors.setTextColor(Color.RED);
                                nextQB.performClick();
                            }
                        }
                    }.start();
                }attempt++;
                if (attempt > 5){
                        errors.setVisibility(View.VISIBLE);
                        nextQB.setText("Go to leaderBoard");
                        nextQB.setVisibility(View.VISIBLE);
                        options.setEnabled(false);
                        Date currentTime = new Date();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        currentDateTime = dateFormat.format(currentTime);
                        String feedback = "your score is: '"+currentScore+"'\n taken in: '"+currentDateTime+" ' ";
                        errors.setTextSize(25);
                        errors.setTextColor(Color.BLUE);
                        errors.setText(feedback);
                        questionTimer.cancel();
                        submitB.setVisibility(View.GONE);
                        addPlayerPoints();
                        nextQB.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                Intent intent=new Intent(Quiz.this,Leaderboard.class);
                                Quiz.this.startActivity(intent);
                                finish();

                            }
                        });
                    }

                }


        });

        submitB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(options.getSelectedItem().toString().equals(correctAnswer)){
                    errors.setTextColor(Color.GREEN);
                    errors.setVisibility(View.VISIBLE);
                    errors.setText("Currect!");
                    nextQB.setText("Next Question");
                    questionTimer.cancel();
                    nextQB.setVisibility(View.VISIBLE);
                    submitB.setVisibility(View.GONE);
                    options.setEnabled(false);
                    currentScore++;
                }
                
                else{
                    errors.setTextColor(Color.RED);
                    errors.setVisibility(View.VISIBLE);
                    errors.setText("Wrong!");
                    nextQB.setText("Next Question");
                    nextQB.setVisibility(View.VISIBLE);
                    submitB.setVisibility(View.GONE);
                    questionTimer.cancel();
                    options.setEnabled(false);
                }
                
                if(attempt == 5){
                    questionTimer.cancel();
                    submitB.setVisibility(View.GONE);
                    nextQB.setText("Show score");
                    questionTimer.cancel();
                    addPlayerPoints();
                }
            }
        });


    }


    private List<Question> loadQuestionsFromCSV() {
        List<Question> questions = new ArrayList<>();
        try {
            AssetManager assetManager = getAssets();
            InputStream is = assetManager.open("Questions.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            reader.readLine();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String questionText = parts[0].trim();
                    String correctAnswer = parts[1].trim();
                    Question question = new Question(questionText, correctAnswer);
                    questions.add(question);
                }
            }
            
            reader.close();
        } catch (IOException e) {
            Log.e("QuizApp", "Cannot read the file " + e.getMessage());
        }
        
        return questions;
    }



    private List<Question> selectRandomQuestions(List<Question> questionList, int count) {
        List<Question> selected = new ArrayList<>();
        List<Integer> usedIndices = new ArrayList<>();

        while (selected.size() < count && selected.size() < questionList.size()) {
            int randomIndex = (int) (Math.random() * questionList.size());
            if (!usedIndices.contains(randomIndex)) {
                usedIndices.add(randomIndex);
                selected.add(questionList.get(randomIndex));
            }
        }
        return selected;
    }

    private void displayQuestion() {
        if (currentQuestionNum < selectedQuestions.size()) {
            Question currentQuestion = selectedQuestions.get(currentQuestionNum);
            questoinN.setText("Question " + (currentQuestionNum + 1));
            questionDetail.setText(currentQuestion.getQuestionText());
            correctAnswer = currentQuestion.getCorrectAnswer();
            currentQuestionNum++;
            
        }

    }

    public List<String> getRandomOptions() {
        List<String> list = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            
                int randomNumber = random.nextInt(200 + 100) - 100; // max = 200; min = -100;
            list.add(String.valueOf(randomNumber));
        }

        list.add(correctAnswer);
        Collections.shuffle(list);
        return list;
    }

    public void addPlayerPoints(){

        DataBaseHelper dataBaseHelper =new DataBaseHelper(Quiz.this,"todo2", null,1);
        
        Cursor lastplayer = dataBaseHelper.getlastPlayer();
        String playerID = "";
        while (lastplayer.moveToNext()){
            playerID= lastplayer.getString(0);
        }
        dataBaseHelper.updatePlayerScore(Integer.parseInt(playerID),currentScore,currentDateTime);




    }

}