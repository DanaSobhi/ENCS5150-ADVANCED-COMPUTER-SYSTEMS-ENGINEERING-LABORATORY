package com.example.todo2;

import java.util.ArrayList;

public class Player {
    private String dPlayerUser;
    private String dPlayerEmail;
    private String dPlayerBirthday;
    private int dPlayerScore;
    private String dPlayerScoreTime;
 //   private ArrayList<Integer> scores;

    public Player() {
    //    this.scores = new ArrayList<>();
    }

    public Player(String dPlayerUser, String dPlayerEmail, String dPlayerBirthday, int dPlayerScore, String dPlayerScoreTime) {
        this.dPlayerUser = dPlayerUser;
        this.dPlayerEmail = dPlayerEmail;
        this.dPlayerBirthday = dPlayerBirthday;
        this.dPlayerScore = dPlayerScore;
        this.dPlayerScoreTime = dPlayerScoreTime;
  //      this.scores = new ArrayList<>();
    }

    public String getdPlayerUser() {
        return dPlayerUser;
    }

    public void setdPlayerUser(String dPlayerUser) {
        this.dPlayerUser = dPlayerUser;
    }

    public String getdPlayerEmail() {
        return dPlayerEmail;
    }

    public void setdPlayerEmail(String dPlayerEmail) {
        this.dPlayerEmail = dPlayerEmail;
    }

    public String getdPlayerBirthday() {
        return dPlayerBirthday;
    }

    public void setdPlayerBirthday(String dPlayerBirthday) {
        this.dPlayerBirthday = dPlayerBirthday;
    }

    public int getdPlayerScore() {
        return dPlayerScore;
    }

    public void setdPlayerScore(int dPlayerScore) {
        this.dPlayerScore = dPlayerScore;
    }

    public String getdPlayerScoreTime() {
        return dPlayerScoreTime;
    }

    public void setdPlayerScoreTime(String dPlayerScoreTime) {
        this.dPlayerScoreTime = dPlayerScoreTime;
    }

/* wont be used , it was just incase the player pressed new quiz he can get another scores.
    public void addScore(int score) {
        scores.add(score);
    }



    public String scoresToString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < scores.size(); i++) {
            result.append(scores.get(i));
            if (i < scores.size() - 1) {
                result.append(", ");
            }
        }
        return result.toString();
    }
*/

    public boolean isValid() {
        return dPlayerUser != null && !dPlayerUser.trim().isEmpty() &&
                dPlayerEmail != null && !dPlayerEmail.trim().isEmpty() &&
                dPlayerBirthday != null && !dPlayerBirthday.trim().isEmpty() &&
                dPlayerScoreTime != null && !dPlayerScoreTime.trim().isEmpty();
    }
}
